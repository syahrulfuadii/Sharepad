package com.example.sharepad.adapter;



import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.sharepad.MyListData;
import com.example.sharepad.R;
import com.example.sharepad.bacaData;
import com.example.sharepad.model.data_cerita;
import com.example.sharepad.updateData;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>{
    private ArrayList<data_cerita> listCerita;
    private Context context;

    //Membuat Interfece
    public interface dataListener{

        void onDeleteData(data_cerita data, int position);
    }

    //Deklarasi objek dari Interfece
    dataListener listener;


    public RecyclerViewAdapter (ArrayList<data_cerita> listCerita,Context context){
        this.listCerita = listCerita;
        this.context = context;
        listener = (MyListData)context;
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        private TextView Judul, Deskripsi, Isi;
        private LinearLayout ListItem;

        ViewHolder(View itemView){
            super(itemView);
            Judul = itemView.findViewById(R.id.judul);
            Deskripsi = itemView.findViewById(R.id.deskripsi);
            Isi = itemView.findViewById(R.id.isi);
            ListItem = itemView.findViewById(R.id.list_item);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View V = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_design,parent,false);
        return new ViewHolder(V);
    }

    @SuppressLint("SetText18n")
    @Override
    public void onBindViewHolder (ViewHolder holder, final int position){
        final String Judul = listCerita.get(position).getJudul();
        final String Deskripsi = listCerita.get(position).getDeskripsi();
        final String Isi = listCerita.get(position).getIsi();

        holder.Judul.setText("Judul: "+Judul);
        holder.Deskripsi.setText("Deskripsi: "+Deskripsi);
        holder.Isi.setText("Isi: "+Isi);

        holder.ListItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putString("dataJudul", listCerita.get(position).getJudul());
                bundle.putString("dataDeskripsi", listCerita.get(position).getDeskripsi());
                bundle.putString("dataIsi", listCerita.get(position).getIsi());
                bundle.putString("dataPrimaryKey", listCerita.get(position).getKey());
                Intent intent = new Intent(view.getContext(), bacaData.class);
                intent.putExtras(bundle);
                context.startActivity((intent));
            }
        });

        holder.ListItem.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(final View view) {
                final String[] action = {"Update", "Delete"};
                AlertDialog.Builder alert = new AlertDialog.Builder(view.getContext());
                alert.setItems(action, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        switch (i){
                            case 0:
                                Bundle bundle = new Bundle();
                                bundle.putString("dataJudul", listCerita.get(position).getJudul());
                                bundle.putString("dataDeskripsi", listCerita.get(position).getDeskripsi());
                                bundle.putString("dataIsi", listCerita.get(position).getIsi());
                                bundle.putString("dataPrimaryKey", listCerita.get(position).getKey());
                                Intent intent = new Intent(view.getContext(), updateData.class);
                                intent.putExtras(bundle);
                                context.startActivity((intent));
                                break;
                            case 1:
                                listener.onDeleteData(listCerita.get(position), position);
                                break;
                        }
                    }
                });
                alert.create();
                alert.show();
                return true;

            }
        });
    }
    @Override
    public int getItemCount(){
        return listCerita.size();
    }

    //Membuat Interfece
//    public interface dataListener{
//        void onDeleteData(data_cerita data, int position);
//    }
//
//    //Deklarasi objek dari Interfece
//    dataListener listener;

    //Membuat Konstruktor, untuk menerima input dari Database
//    public RecyclerViewAdapter(ArrayList listCerita, Context context) {
//        this.listCerita = listCerita;
//        this.context = context;
//        listener = (MyListData)context;
//    }
}
