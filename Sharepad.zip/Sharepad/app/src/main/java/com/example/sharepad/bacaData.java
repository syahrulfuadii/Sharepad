package com.example.sharepad;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class bacaData extends AppCompatActivity {

    private TextView judulBaca, deskripsiBaca, isiBaca;
    private Button updateBaca;
    private DatabaseReference database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_baca_data);
        judulBaca = findViewById(R.id.baca_judul);
        deskripsiBaca = findViewById(R.id.baca_deskripsi);
        isiBaca = findViewById(R.id.baca_isi);
        updateBaca = findViewById(R.id.baca_update);
        database = FirebaseDatabase.getInstance().getReference();
        ambildata();
        updateBaca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(bacaData.this,updateData.class);
                startActivity(intent);
            }
        });
    }

    private void ambildata() {
        final String getJudul = getIntent().getExtras().getString("dataJudul");
        final String getDeskripsi = getIntent().getExtras().getString("dataDeskripsi");
        final String getIsi = getIntent().getExtras().getString("dataIsi");
        judulBaca.setText(getJudul);
        deskripsiBaca.setText(getDeskripsi);
        isiBaca.setText(getIsi);
    }
}
