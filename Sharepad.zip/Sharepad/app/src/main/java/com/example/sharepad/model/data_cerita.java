package com.example.sharepad.model;

public class data_cerita {
    private String judul;
    private String deskripsi;
    private String isi;
    private String key;

    public String getKey(){
        return key;
    }

    public void setKey(String key){
        this.key = key;
    }

    public String getJudul(){
        return judul;
    }

    public void setJudul(String judul){
        this.judul = judul;
    }

    public String getDeskripsi(){
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi){
        this.deskripsi = deskripsi;
    }

    public String getIsi(){
        return isi;
    }

    public void setIsi(String isi){
        this.isi = isi;
    }

    public data_cerita(){
    }

    public data_cerita(String judul, String deskripsi, String isi){
        this.judul = judul;
        this.deskripsi = deskripsi;
        this.isi = isi;
    }
}
