package com.example.sharepad;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.sharepad.model.data_cerita;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class updateData extends AppCompatActivity {
    private EditText judulBaru,deskripsiBaru,isiBaru;
    private Button update;
    private DatabaseReference reference;
    private String cekJudul,cekDeskripsi,cekIsi;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_data);
        getSupportActionBar().setTitle("Update Cerita");
        judulBaru = findViewById(R.id.new_judul);
        deskripsiBaru = findViewById(R.id.new_deskripsi);
        isiBaru = findViewById(R.id.new_isi);
        update = findViewById(R.id.update);

        reference = FirebaseDatabase.getInstance().getReference();
        getData();
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cekJudul = judulBaru.getText().toString();
                cekDeskripsi = deskripsiBaru.getText().toString();
                cekIsi = isiBaru.getText().toString();

                if (isEmpty(cekJudul) || isEmpty(cekDeskripsi) || isEmpty(cekIsi)){
                    Toast.makeText(updateData.this, "Data tidak boleh ada yang kosong", Toast.LENGTH_SHORT).show();
                }else {
                    data_cerita cerita = new data_cerita();
                    cerita.setJudul(judulBaru.getText().toString());
                    cerita.setDeskripsi(deskripsiBaru.getText().toString());
                    cerita.setIsi(isiBaru.getText().toString());
                    updateCerita(cerita);
                }
            }
        });
    }

    private boolean isEmpty(String s){
        return TextUtils.isEmpty(s);
    }

    private void getData(){
        final String getJudul = getIntent().getExtras().getString("dataJudul");
        final String getDeskripsi = getIntent().getExtras().getString("dataDeskkripsi");
        final String getIsi = getIntent().getExtras().getString("dataIsi");
        judulBaru.setText(getJudul);
        deskripsiBaru.setText(getDeskripsi);
        isiBaru.setText(getIsi);
    }

    private void updateCerita(data_cerita cerita){
//      final String getKey = getIntent().getExtras().getString("getPrimaryKey");

        reference.child("Cerita")
                .child(cerita.getJudul())
                .setValue(cerita)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        judulBaru.setText("");
                        deskripsiBaru.setText("");
                        isiBaru.setText("");
                        Toast.makeText(updateData.this, "Data Berhasil diubah", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
    }
}
