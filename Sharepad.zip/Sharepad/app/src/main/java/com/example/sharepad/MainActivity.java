package com.example.sharepad;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.sharepad.model.data_cerita;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import static android.text.TextUtils.isEmpty;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText Judul, Deskripsi, Isi;
    private Button btnTambah;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Judul = findViewById(R.id.cerita_judul);
        Deskripsi = findViewById(R.id.cerita_deskripsi);
        Isi = findViewById(R.id.cerita_isi);
        btnTambah = findViewById(R.id.btn_tambah);
        btnTambah.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference getReference;

        String getJudul = Judul.getText().toString();
        String getDeskripsi = Deskripsi.getText().toString();
        String getIsi = Isi.getText().toString();

        getReference = database.getReference();

        if (isEmpty(getJudul) && isEmpty(getDeskripsi) && isEmpty(getIsi)){
            Toast.makeText(MainActivity.this, "Data tidak boleh ada yang kosong", Toast.LENGTH_SHORT).show();
        } else {
            auth = FirebaseAuth.getInstance();
            getReference.child("Cerita").child(getJudul)
                    .setValue(new data_cerita(getJudul, getDeskripsi, getIsi))
                    .addOnSuccessListener(this, new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Judul.setText("");
                            Deskripsi.setText("");
                            Isi.setText("");
                            Toast.makeText(MainActivity.this,"Data tersimpan",Toast.LENGTH_SHORT).show();
                        }
                    });
        }

        startActivity(new Intent(MainActivity.this,MyListData.class));
    }
}
